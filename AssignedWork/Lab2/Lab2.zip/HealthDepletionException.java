public class HealthDepletionException extends Exception {
    public HealthDepletionException(String message) {
        super(message);
    }
}
